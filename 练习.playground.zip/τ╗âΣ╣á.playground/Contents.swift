//: Playground - noun: a place where people can play

import UIKit

var hours = 24
var PI = 3.14
var swiftstring = "swift is fun"
var swiftIsfun = true
var me = ("aa",11,"111@qq.com")
me.0
me.1
 PI = 3.1415
let minuate = 11



