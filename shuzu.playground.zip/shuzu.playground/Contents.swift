//: Playground - noun: a place where people can play

import UIKit

var arr = [11,22,44,33,5,7,59,6,8,34]
print ("无序的数组")
print(arr)

for j in 0...9{
    for i in 0...8{
        if arr[i]>arr[i+1]
        {
            arr [i]=arr[i]+arr[i+1]
            arr[i+1]=arr[i]-arr[i+1]
            arr [i]=arr[i]-arr[i+1]
        }
    }
}
print ("排序后的数组")
print (arr)