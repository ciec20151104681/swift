//: Playground - noun: a place where people can play

import UIKit

Int.min
Int.max

Int64.min
Int64.max

let fifteenindecimal = 10
var onethirdinFloat : Float = 1/3
var onethirdinDouble : Double = 1/3
print (onethirdinFloat)
print (onethirdinDouble)
var PI = 314e-2

var three = 3
type(of:three)
var zeropointfourteen = 0.14
type(of:zeropointfourteen)

PI = 3 + 0.14
type(of:PI)
PI = Double(three) + zeropointfourteen




